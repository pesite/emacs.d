Usage:
  (require 'flymake-php)
  (add-hook 'php-mode-hook 'flymake-php-load)

Uses flymake-easy, from https://github.com/purcell/flymake-easy
