Gradle integration into Emacs, through compile-mode.
see documentation on https://github.com/jacobono/emacs-gradle-mode
