This extension provides a way to complete with popup menu like:

    def-!-
    +-----------------+
    |defun::::::::::::|
    |defvar           |
    |defmacro         |
    |       ...       |
    +-----------------+

You can complete by typing and selecting menu.

Entire documents are located in doc/ directory.
Take a look for information.

Enjoy!
