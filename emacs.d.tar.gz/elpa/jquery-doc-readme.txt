provides completion source for autocomplete, documentation lookup
