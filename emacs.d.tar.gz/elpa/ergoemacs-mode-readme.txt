This keybinding set puts the most frequently used Emacs keyboard
shortcuts into the most easy-to-type spots.

For complete detail, see:
http://ergoemacs.github.io/

Todo:



Acknowledgment:
Thanks to Shahin Azad for persian layout (fa) ishahinism at g
mail.com
Thanks to Thomas Rikl workhorse.t at googlemail.com for german layout
Thanks to Baptiste Fouques  bateast at bat.fr.eu.org for bepo layout
Thanks to Andrey Kotlarski (aka m00naticus) for a patch on 2012-12-08
Thanks to Nikolaj Schumacher for his implementation of extend-selection.
Thanks to Andreas Politz and Nikolaj Schumacher for correcting/improving implementation of toggle-letter-case.
Thanks to Lennart Borgman for several suggestions on code to prevent shortcuts involving shift key to start select text when CUA-mode is on.
Thanks to marciomazza for spotting several default bindings that
should have been unbound.
Thanks to lwarxx for bug report on diff-mode
Thanks to maddin for ergoemacs-global/local-set-key functions and ergoemacs-hook-modes improvements.
Thanks to many users who send in comments and appreciations on this.
Layout contributors:
Danish layout “da”.  Contributors: Michael Budde
UK QWERTY layout “gb”.  Contributor: Jorge Dias (aka theturingmachine)
UK Dvorak layout “gb-dv”.  Contributor: Phillip Wood
French AZERTY layout “fr”.  Contributor: Alexander Doe
Italian QWERTY layout “it”.  Contributor: David Capello, Francesco Biccari


