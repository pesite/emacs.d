You should find probe.php in the same directory as this file.

The project is hosted at https://github.com/sabof/php-eldoc
The latest version, and all the relevant information can be found there.
