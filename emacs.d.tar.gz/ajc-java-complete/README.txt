* This is "Auto Java Complete".
  When you edit a java file or jsp file ,it can dropdown a menu to show
  the candidates using auto-complete and yasnippet.
* page on emacswiki:
  http://www.emacswiki.org/emacs/AutoJavaComplete

* page on github.com
  https://github.com/emacs-java/auto-java-complete
* whitypig make a fork on
           https://github.com/whitypig/ajc-java-complete
           and this fork support multiple tag files
* Mail List:
  emacsjava@googlegroups.com

* Video demo
  https://www.dropbox.com/s/f8dr9utzhh0usay/auto-java-complete.mp4.7z
